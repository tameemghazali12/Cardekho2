document.addEventListener("DOMContentLoaded", function () {
    const carForm = document.getElementById("carForm");
    const responseContainer = document.getElementById("responseContainer");

    carForm.addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent the default form submission

        // Get selected car options
        const carOptions = document.querySelectorAll('input[name="carOption[]"]:checked');
        const selectedOptions = Array.from(carOptions).map(option => option.value).join(", ");

        // Get other form inputs
        const name = document.getElementById("name").value;
        const phone = document.getElementById("phone").value;
        const email = document.getElementById("email").value;
        const address = document.getElementById("address").value;

        // Display the submitted data
        document.getElementById("selectedOptions").textContent = `Car Options: ${selectedOptions}`;
        document.getElementById("submittedName").textContent = name;
        document.getElementById("submittedPhone").textContent = phone;
        document.getElementById("submittedEmail").textContent = email;
        document.getElementById("submittedAddress").textContent = address;

        // Show the response container
        responseContainer.style.display = "block";
    });
});
