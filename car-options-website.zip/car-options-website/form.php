<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $data = json_decode(file_get_contents('php://input'), true);

    $carOptions = $data['car_options'];
    $name = $data['name'];
    $phone = $data['phone'];
    $email = $data['email'];
    $address = $data['address'];

    // Create or open a CSV file and append the data
    $csvFileName = 'user_responses.csv';
    $csvFile = fopen($csvFileName, 'a');

    // Check if the file exists and write the data
    if ($csvFile !== false) {
        fputcsv($csvFile, [$carOptions, $name, $phone, $email, $address]);
        fclose($csvFile);
        echo "Form submitted successfully!";
    } else {
        echo "Error: Unable to open the file.";
    }
}
?>
